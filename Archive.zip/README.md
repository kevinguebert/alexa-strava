#Alexa & Sailing

As an avid sailor, maybe it would be cool to get some sailing information through Alexa. 

Looking for wind speed in particular - using Darksky
